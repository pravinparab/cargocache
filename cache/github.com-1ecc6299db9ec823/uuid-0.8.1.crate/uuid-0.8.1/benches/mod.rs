#![feature(test)]

#[cfg(feature = "slog")]
pub mod slog_support;
