import * as wasm from './reference_test_bg.wasm';

