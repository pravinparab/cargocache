// enable-externref
