# `binary-install`
> install a binary from a path to a global cache
