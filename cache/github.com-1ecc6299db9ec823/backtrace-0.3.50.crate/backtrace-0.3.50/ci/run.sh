#!/bin/sh

set -ex

cargo test --target $TARGET
