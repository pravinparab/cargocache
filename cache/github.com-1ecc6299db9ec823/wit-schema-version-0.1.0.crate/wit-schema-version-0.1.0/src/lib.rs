pub const VERSION: &str = env!("CARGO_PKG_VERSION");
pub const SECTION_NAME: &str = "wasm-interface-types";
