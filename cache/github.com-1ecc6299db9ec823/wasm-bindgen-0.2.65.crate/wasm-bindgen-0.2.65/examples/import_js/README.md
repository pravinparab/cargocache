# Importing non-browser JS

[View documentation for this example online][dox] or [View compiled example
online][compiled]

[compiled]: https://rustwasm.github.io/wasm-bindgen/exbuild/import_js/
[dox]: https://rustwasm.github.io/docs/wasm-bindgen/examples/import-js.html

You can build the example locally with:

```
$ npm run serve
```

and then visiting http://localhost:8080 in a browser should run the example!
