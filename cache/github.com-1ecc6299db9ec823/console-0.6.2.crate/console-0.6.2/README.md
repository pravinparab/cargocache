# console

A console and terminal abstraction for Rust.

Adds colors and other useful things to your terminal life.
