/// Key mapping
///
/// This is an incomplete mapping of keys that are supported for reading
/// from the keyboard.
#[derive(Copy, Clone, PartialEq, Eq, Debug)]
pub enum Key {
    Unknown,
    ArrowLeft,
    ArrowRight,
    ArrowUp,
    ArrowDown,
    Enter,
    Escape,
    Char(char),
    #[doc(hidden)]
    __More,
}
