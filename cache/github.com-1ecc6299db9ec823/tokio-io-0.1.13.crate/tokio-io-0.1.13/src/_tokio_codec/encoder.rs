// For now, we need to keep the implementation of Encoder in tokio_io.

pub use codec::Encoder;
