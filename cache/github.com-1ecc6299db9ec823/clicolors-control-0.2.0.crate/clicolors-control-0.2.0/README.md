# clicolors-control

A utility library for Rust that acts as a common place to control
the colorization for CLI tools.
