# Getting Started

You can create a new Rust-WebAssembly webpack project by using the [rustwasm webpack-template].

Run:

```
npm init rust-webpack my-app
```

The last argument will be your project name. After you run the command, you will have a
directory with a new project, ready to go. We'll talk about what's been included in this
template further in this guide.

[rustwasm webpack-template]: https://github.com/rustwasm/rust-webpack-template
