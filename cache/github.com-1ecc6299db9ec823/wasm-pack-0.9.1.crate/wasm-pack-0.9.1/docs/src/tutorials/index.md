# Tutorials

We have two tutorials that help you get started with `wasm-pack`:

- If you want to create and publish a package: [npm browser packages]
- If you'd like to develop a Wasm library alongside a JavaScript application using Webpack: [Hybrid applications with Webpack]

[npm browser packages]: npm-browser-packages/index.html
[Hybrid applications with Webpack]: hybrid-applications-with-webpack/index.html
