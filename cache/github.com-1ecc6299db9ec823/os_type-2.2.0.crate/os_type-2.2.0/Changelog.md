<a name="v2.2.0"></a>
## v2.2.0 (2018-09-16)


#### Features

*   add support for Manjaro Linux ([a4fddb88](a4fddb88))



<a name="v2.1.1"></a>
## v2.1.1 (2018-09-16)


#### Bug Fixes

*   Update to regex 1.0 ([f2afcef5](f2afcef5))



<a name="v2.1.0"></a>
## v2.1.0 (2018-09-16)


#### Features

*   add support for os-release ([c14c19f0](c14c19f0))
*   add openSUSE support ([006de390](006de390))



<a name="v2.0.0"></a>
## v2.0.0 (2017-05-19)




<a name="v1.0.0"></a>
## v1.0.0 (2017-05-11)

### Features

*   Provide OS Version
*   BREAKING CHANGE: current_platform now returns a struct instead of an enum
*   BREAKING CHANGE: We do not support Windows anymore

<a name="v0.6.0"></a>
## v0.6.0 (2016-02-07)

#### Features

*   implement clone trait for OSType enum ([42298ddd](42298ddd))



