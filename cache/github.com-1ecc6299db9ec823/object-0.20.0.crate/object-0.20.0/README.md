# `object`

The `object` crate provides a unified interface to working with object files
across platforms. It supports reading object files and executable files,
and writing object files.
